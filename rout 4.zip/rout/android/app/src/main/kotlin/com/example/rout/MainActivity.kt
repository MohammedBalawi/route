package com.example.rout

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
