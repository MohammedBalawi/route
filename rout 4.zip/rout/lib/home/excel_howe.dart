import 'dart:io';
import 'package:excel/excel.dart';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../shared_pref/shared.dart';

class test extends StatefulWidget {
  const test({super.key});

  @override
  State<test> createState() => _testState();
}

class _testState extends State<test> {
  bool _show = false;
  Excel? excelData;
  File? selectedFile;
  List<Map<String, dynamic>> _excelFiles = [];

  Future<void> _pickFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['xlsx'],
    );

    if (result != null) {
      String filePath = result.files.single.path!;
      File file = File(filePath);
      List<int> bytes = await file.readAsBytes();
      var excel = Excel.decodeBytes(bytes);
      List<List<dynamic>> rows = [];
      _show = true;

      for (var table in excel.tables.keys) {
        for (var row in excel.tables[table]!.rows) {
          rows.add(row.map((cell) => cell?.value ?? '').toList());
        }
      }

      setState(() {
        _excelFiles.add({'name': result.files.single.name, 'rows': rows});
      });
    }
  }

  Future<void> _pickFileColor() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['xlsx'],
    );
    if (result != null) {
      selectedFile = File(result.files.single.path!);
      var bytes = selectedFile!.readAsBytesSync();
      excelData = Excel.decodeBytes(bytes);
      setState(() {});
    }
  }

  void _deleteFile(int index) {
    setState(() {
      _excelFiles.removeAt(index);
      if (_excelFiles.isEmpty) {
        _show = false;
      }
    });
  }

  void removeDuplicateRows() {
    if (excelData != null) {
      for (var sheet in excelData!.sheets.values) {
        final uniqueRows = <String>{};
        sheet.rows.retainWhere((row) {
          final rowStr = row.map((e) => e?.value.toString()).join();
          return uniqueRows.add(rowStr);
        });
      }
      setState(() {});
    }
  }

  void _colorDuplicates() {
    if (excelData != null) {
      for (var sheet in excelData!.sheets.values) {
        final seen = <dynamic>{};
        for (var row in sheet.rows) {
          if (!seen.add(row[0]?.value)) {
            row[0]?.cellStyle = CellStyle(backgroundColorHex: "#FF0000");
            row[1]?.cellStyle = CellStyle(backgroundColorHex: "#FF0000");
          }
        }
      }
      setState(() {});
    }
  }

  void _showResultDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('اختار طريقة الحذف'),
          content: Row(
            children: [
              IconButton(
                  onPressed: () {
                    Navigator.pushReplacementNamed(
                        context, '/excel_delete_screen');
                  },
                  icon: const Text('ملف جديد')),
              IconButton(
                  onPressed: () {
                    Navigator.pushReplacementNamed(
                        context, '/excel_remover_screen');
                  },
                  icon: const Text('نفس الملف'))
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('موافق'),
            ),
          ],
        );
      },
    );
  }
  Future<void> _logout() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setBool('loggedIn', false);
    Navigator.pushReplacementNamed(context, '/login_screen');
  }
  Future<void> _saveFile() async {
    if (selectedFile != null && excelData != null) {
      var fileBytes = excelData!.encode();
      if (fileBytes != null) {
        await File(selectedFile!.path).writeAsBytes(fileBytes, flush: true);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('File saved successfully.')),
        );
      }
    }
  }
  void  _showM(BuildContext context) async {
    bool result = await showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title:  Text('Logout'),
            content: Text('Do You Logout New ?'),

            actions: [
              MaterialButton(
                onPressed: () {
                  Navigator.pop(context, true);
                },
                child:  Text(
                  'Yes',
                  style: TextStyle(color: Colors.blue),
                ),
              ),
              MaterialButton(
                onPressed: () {
                  Navigator.pop(context, false);
                },
                child:  Text(
                  'No',
                  style: TextStyle(color: Colors.red),
                ),
              ),
            ],
          );
        });
    if (result ?? false) {
      _claer(context);
    }
  }

  Future<void> _claer(BuildContext context) async {
    bool clear = await SharedPrefController().clear();

    if (clear) {
      Get.delete();
      Navigator.pushReplacementNamed(context, '/login_screen');
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      body: _show == false
          ? ListView(children: [
              const SizedBox(
                height: 10,
              ),
              Center(
                  child: Container(
                      height: 50,
                      width: 750,
                      decoration: BoxDecoration(
                        color: const Color(0xff357188),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Center(
                          child: Text(
                        'Test',
                        style: TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 25),
                      )))),
              Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                      alignment: AlignmentDirectional.topStart,
                      child: Row(
                        children: [
                          Column(
                            children: [
                              Column(
                                children: [
                                  Container(
                                    height: 500,
                                    width: 200,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(30),
                                      color: const Color(0xff357188),
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.all(10),
                                      child: Center(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            Center(
                                              child: Container(
                                                child: const Text(
                                                  'العمليات',
                                                  style: TextStyle(
                                                      fontSize: 24,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      color: Colors.black),
                                                ),
                                              ),
                                            ),
                                            const SizedBox(
                                              height: 20,
                                            ),
                                            Center(
                                              child: Container(
                                                height: 40,
                                                width: 100,
                                                decoration: BoxDecoration(
                                                    color: Colors.white70,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            40)),
                                                child: Center(
                                                    child: InkWell(
                                                        onTap: () {
                                                          _showResultDialog();
                                                        },
                                                        child: const Text(
                                                            'حذف المكرر'))),
                                              ),
                                            ),
                                            const SizedBox(
                                              height: 10,
                                            ),
                                            Center(
                                              child: Container(
                                                height: 40,
                                                width: 100,
                                                decoration: BoxDecoration(
                                                    color: Colors.white70,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            40)),
                                                child: Center(
                                                    child: InkWell(
                                                        onTap: () {
                                                          Navigator
                                                              .pushReplacementNamed(
                                                                  context,
                                                                  '/excel_processor');
                                                        },
                                                        child: const Text(
                                                            'تلوين المكرر'))),
                                              ),
                                            ),
                                            const SizedBox(
                                              height: 10,
                                            ),
                                            Center(
                                              child: Container(
                                                height: 40,
                                                width: 100,
                                                decoration: BoxDecoration(
                                                    color: Colors.white70,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            40)),
                                                child: Center(
                                                    child: InkWell(
                                                        onTap: () {
                                                          Navigator
                                                              .pushReplacementNamed(
                                                                  context,
                                                                  '/excel_merger_screen');
                                                        },
                                                        child: const Text('الدمج'))),
                                              ),
                                            ),
                                            const SizedBox(
                                              height: 10,
                                            ),
                                            Center(
                                              child: Container(
                                                height: 40,
                                                width: 100,
                                                decoration: BoxDecoration(
                                                    color: Colors.white70,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            40)),
                                                child: Center(
                                                    child: InkWell(
                                                        onTap: () {
                                                          Navigator
                                                              .pushReplacementNamed(
                                                                  context,
                                                                  '/excel_comparison_screen');
                                                        },
                                                        child:
                                                            const Text('المقارنة'))),
                                              ),
                                            ),
                                            const SizedBox(
                                              height: 10,
                                            ),
                                            Center(
                                              child: Container(
                                                height: 40,
                                                width: 100,
                                                decoration: BoxDecoration(
                                                    color: Colors.white70,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            40)),
                                                child: Center(
                                                    child: InkWell(
                                                        onTap: () {
                                                          Navigator
                                                              .pushReplacementNamed(
                                                                  context,
                                                                  '/excel_picker_screen');
                                                        },
                                                        child: const Text('الفحص'))),
                                              ),
                                            ),
                                            const SizedBox(
                                              height: 10,
                                            ),
                                            Center(
                                              child: Container(
                                                height: 40,
                                                width: 100,
                                                decoration: BoxDecoration(
                                                    color: Colors.white70,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            40)),
                                                child: Center(
                                                    child: InkWell(
                                                        onTap: () {
                                                         Navigator.pushReplacementNamed(context, '/notes_screen');
                                                        },
                                                        child: const Text('النوت'))),
                                              ),
                                            ),
                                            const SizedBox(
                                              height: 10,
                                            ),
                                            Center(
                                              child: Container(
                                                height: 40,
                                                width: 100,
                                                decoration: BoxDecoration(
                                                    color: Colors.white70,
                                                    borderRadius:
                                                    BorderRadius.circular(
                                                        40)),
                                                child: Center(
                                                    child: InkWell(
                                                        onTap: () {
                                                          // Navigator.pushReplacementNamed(context, '/login_screen');
                                                          // _logout;
                                                          _showM(context);
                                                        },
                                                        child: const Text('تسجيل الخروج'))),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(
                            width: 30,
                          ),
                          Row(
                            children: [
                              Container(
                                height: 500,
                                width: 500,
                                // color: Colors.red,
                                decoration: BoxDecoration(
                                    color: Colors.grey,
                                    borderRadius: BorderRadius.circular(20)),
                                child: Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      IconButton(
                                          onPressed: () {
                                            _pickFile();
                                          },
                                          icon: const Icon(
                                            Icons.add_circle_outline,
                                            size: 100,
                                            color: Colors.white54,
                                          )),
                                      const Text(
                                        'اضافة ملف',
                                        style: TextStyle(
                                          color: Colors.white54,
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ))),
            ])
          : Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Center(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 40, vertical: 16),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30)),
                      ),
                      onPressed: _pickFile,
                      child: const Text('Choose Excel File'),
                    ),
                  ),
                  Expanded(
                    child: ListView.builder(
                      itemCount: _excelFiles.length,
                      itemBuilder: (context, index) {
                        final file = _excelFiles[index];
                        // FavoriteProvider(file as DataProvider);
                        return Card(
                          margin: const EdgeInsets.all(8.0),
                          child: Column(
                            children: [
                              ListTile(
                                title: Text(file['name']),
                                trailing: IconButton(
                                  icon: const Icon(Icons.delete),
                                  color: Colors.red,
                                  onPressed: () => _deleteFile(index),
                                ),
                              ),
                              SingleChildScrollView(
                                scrollDirection: Axis.horizontal,
                                child: DataTable(
                                  columns: [
                                    for (int i = 0;
                                        i < file['rows'].first.length;
                                        i++)
                                      DataColumn(label: Text('Col $i')),
                                  ],
                                  rows: file['rows'].map<DataRow>((row) {
                                    return DataRow(
                                      cells: row.map<DataCell>((cell) {
                                        return DataCell(Text(cell.toString()));
                                      }).toList(),
                                    );
                                  }).toList(),
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}
