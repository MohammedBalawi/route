//
// import 'dart:io';
// import 'package:excel/excel.dart';
// import 'package:file_picker/file_picker.dart';
// import 'package:flutter/material.dart';
// import 'package:path_provider/path_provider.dart';
//
// class ExcelMergerScreen extends StatefulWidget {
//   const ExcelMergerScreen({super.key});
//
//   @override
//   _ExcelMergerScreenState createState() => _ExcelMergerScreenState();
// }
//
// class _ExcelMergerScreenState extends State<ExcelMergerScreen> {
//   String? mergedFilePath;
//
//   Future<void> pickAndMergeFiles() async {
//     try {
//       // Pick two files
//       FilePickerResult? result = await FilePicker.platform.pickFiles(
//         allowMultiple: true,
//         type: FileType.custom,
//         allowedExtensions: ['xlsx'],
//       );
//
//       if (result == null || result.files.length != 2) {
//         return;
//       }
//
//       var file1 = result.files[0];
//       var file2 = result.files[1];
//
//       // Read Excel files
//       var bytes1 = File(file1.path!).readAsBytesSync();
//       var bytes2 = File(file2.path!).readAsBytesSync();
//
//       var excel1 = Excel.decodeBytes(bytes1);
//       var excel2 = Excel.decodeBytes(bytes2);
//
//       // Create a new Excel file
//       var excel = Excel.createExcel();
//       Sheet sheet = excel['Sheet1'];
//
//       // Get data from both files
//       var sheet1 = excel1.tables[excel1.tables.keys.first]!;
//       var sheet2 = excel2.tables[excel2.tables.keys.first]!;
//
//       // Append data from the first file
//       for (var row in sheet1.rows) {
//         List<Object?> newRow = [];
//         for (var cell in row) {
//           if (cell?.value != null) {
//             newRow.add(cell!.value.toString());
//           }
//         }
//         sheet.appendRow(newRow);
//       }
//
//       // Append data from the second file
//       for (var row in sheet2.rows) {
//         List<Object?> newRow = [];
//         for (var cell in row) {
//           if (cell?.value != null) {
//             newRow.add(cell!.value.toString());
//           }
//         }
//         sheet.appendRow(newRow);
//       }
//
//       // Save the new file
//       final directory = await getApplicationDocumentsDirectory();
//       String newPath = '${directory.path}/merged_data.xlsx';
//       File(newPath)
//         ..createSync(recursive: true)
//         ..writeAsBytesSync(excel.encode()!);
//
//       setState(() {
//         mergedFilePath = newPath;
//       });
//
//       _showResultDialog("تم دمج البيانات وحفظها في: $newPath");
//     } catch (e) {
//       print("Error: $e");
//     }
//   }
//
//   void _showResultDialog(String message) {
//     showDialog(
//       context: context,
//       builder: (context) {
//         return AlertDialog(
//           title: const Text('نتيجة الدمج'),
//           content: Text(message),
//           actions: [
//             TextButton(
//               onPressed: () => Navigator.of(context).pop(),
//               child: const Text('موافق'),
//             ),
//           ],
//         );
//       },
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Row(
//           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//           children: [
//             IconButton(
//               onPressed: () {
//                 Navigator.pushReplacementNamed(context, '/test_screen');
//               },
//               icon: const Icon(Icons.arrow_back_ios_new),
//             ),
//             const Text('دمج ملفات Excel'),
//             const Text(''),
//           ],
//         ),
//       ),
//       body: Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             ElevatedButton(
//               onPressed: pickAndMergeFiles,
//               child: const Text(
//                 'اختر ملفين للدمج',
//                 style: TextStyle(
//                   color: Colors.green,
//                 ),
//               ),
//             ),
//             SizedBox(height: 20),
//             if (mergedFilePath != null)
//               Text(
//                 'تم حفظ الملف المدمج في: $mergedFilePath',
//                 textAlign: TextAlign.center,
//               ),
//           ],
//         ),
//       ),
//     );
//   }
// }

import 'dart:io';
import 'package:excel/excel.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';

class ExcelMergerScreen extends StatefulWidget {
  const ExcelMergerScreen({super.key});

  @override
  _ExcelMergerScreenState createState() => _ExcelMergerScreenState();
}

class _ExcelMergerScreenState extends State<ExcelMergerScreen> {
  String? filePath1;
  String? filePath2;
  String? mergedFilePath;

  Future<void> pickFile(int fileNumber) async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['xlsx'],
      );

      if (result != null && result.files.isNotEmpty) {
        setState(() {
          if (fileNumber == 1) {
            filePath1 = result.files.first.path;
          } else if (fileNumber == 2) {
            filePath2 = result.files.first.path;
          }
        });
      }
    } catch (e) {
      print("Error: $e");
    }
  }

  Future<void> mergeFiles() async {
    if (filePath1 == null || filePath2 == null) {
      _showResultDialog("يجب اختيار كلا الملفين أولاً.");
      return;
    }

    try {
      var bytes1 = File(filePath1!).readAsBytesSync();
      var bytes2 = File(filePath2!).readAsBytesSync();

      var excel1 = Excel.decodeBytes(bytes1);
      var excel2 = Excel.decodeBytes(bytes2);

      var excel = Excel.createExcel();
      Sheet sheet = excel['Sheet1'];

      var sheet1 = excel1.tables[excel1.tables.keys.first]!;
      var sheet2 = excel2.tables[excel2.tables.keys.first]!;

      for (var row in sheet1.rows) {
        List<Object?> newRow = [];
        for (var cell in row) {
          if (cell?.value != null) {
            newRow.add(cell!.value.toString());
          }
        }
        sheet.appendRow(newRow);
      }

      for (var row in sheet2.rows) {
        List<Object?> newRow = [];
        for (var cell in row) {
          if (cell?.value != null) {
            newRow.add(cell!.value.toString());
          }
        }
        sheet.appendRow(newRow);
      }

      final directory = await getApplicationDocumentsDirectory();
      String newPath = '${directory.path}/merged_data.xlsx';
      File(newPath)
        ..createSync(recursive: true)
        ..writeAsBytesSync(excel.encode()!);

      setState(() {
        mergedFilePath = newPath;
      });

      _showResultDialog("تم دمج البيانات وحفظها في: $newPath");
    } catch (e) {
      print("Error: $e");
    }
  }

  void _showResultDialog(String message) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('نتيجة الدمج'),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('موافق'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            IconButton(
              onPressed: () {
                Navigator.pushReplacementNamed(context, '/test_screen');
              },
              icon: const Icon(Icons.arrow_back_ios_new),
            ),
            const Text('دمج ملفات Excel'),
            const Text(''),
          ],
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () => pickFile(1),
              child: const Text('اختر الملف الأول',style: TextStyle(
                  color: Colors.green
              ),),
            ),
            if (filePath1 != null)
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  'المسار الاول: $filePath1',
                  textAlign: TextAlign.center,
                ),
              ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => pickFile(2),
              child: const Text('اختر الملف الثاني',style: TextStyle(
    color: Colors.green
    ),),
            ),
            if (filePath2 != null)
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  'المسارالتاني: $filePath2',
                  textAlign: TextAlign.center,
                ),
              ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: mergeFiles,
              child: const Text('دمج الملفات',style: TextStyle(
                color: Colors.green
              ),),
            ),
            SizedBox(height: 20),
            if (mergedFilePath != null)
              Text(
                'تم حفظ الملف المدمج في: $mergedFilePath',
                textAlign: TextAlign.center,
              ),
          ],
        ),
      ),
    );
  }
}