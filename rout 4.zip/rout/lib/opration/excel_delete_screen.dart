import 'dart:io';
import 'package:excel/excel.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
/// delete in new file
class ExcelDeleteScreen extends StatefulWidget {
  const ExcelDeleteScreen({super.key});

  @override
  _ExcelDeleteScreenState createState() => _ExcelDeleteScreenState();
}

class _ExcelDeleteScreenState extends State<ExcelDeleteScreen> {
  String? cleanedFilePath;

  Future<void> pickAndCleanFile() async {
    try {
      // Pick a single file
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        allowMultiple: false,
        type: FileType.custom,
        allowedExtensions: ['xlsx'],
      );

      if (result == null) {
        return;
      }

      var file = result.files.first;

      // Read the Excel file
      var bytes = File(file.path!).readAsBytesSync();
      var excel = Excel.decodeBytes(bytes);

      // Create a new Excel file
      var newExcel = Excel.createExcel();
      Sheet newSheet = newExcel['Sheet1'];

      // Get data from the file and remove duplicates based on the first three columns
      var sheet = excel.tables[excel.tables.keys.first]!;
      Set<String> uniqueKeys = {};

      for (var row in sheet.rows) {
        if (row.isNotEmpty) {
          String key = '';
          for (int i = 0; i < 3; i++) {
            if (i < row.length && row[i]?.value != null) {
              key += '${row[i]?.value}-';
            }
          }
          if (!uniqueKeys.contains(key)) {
            uniqueKeys.add(key);

            List<Object?> newRow = [];
            for (var cell in row) {
              if (cell?.value != null) {
                newRow.add(cell!.value.toString());
              }
            }
            newSheet.appendRow(newRow);
          }
        }
      }

      // Save the cleaned file
      final directory = await getApplicationDocumentsDirectory();
      String newPath = '${directory.path}/cleaned_data.xlsx';
      File(newPath)
        ..createSync(recursive: true)
        ..writeAsBytesSync(newExcel.encode()!);

      setState(() {
        cleanedFilePath = newPath;
      });

      _showResultDialog("تم إزالة المكرر وحفظ البيانات في: $newPath");
    } catch (e) {
      print("Error: $e");
    }
  }

  void _showResultDialog(String message) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('نتيجة التنظيف'),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('موافق'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            IconButton(
              onPressed: () {
                // Navigator.pushReplacementNamed(context,'/test_screen');
              },
              icon: const Text(''),
            ),
            const Text('تنظيف ملف Excel'),
            const Text(''),
          ],
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: pickAndCleanFile,
              child: const Text(
                'اختر ملف للتنظيف',
                style: TextStyle(
                  color: Colors.green,
                ),
              ),
            ),
            SizedBox(height: 20),
            if (cleanedFilePath != null)
              Text(
                'تم حفظ الملف المنظف في: $cleanedFilePath',
                textAlign: TextAlign.center,
              ),
          ],
        ),
      ),
    );
  }
}