// import 'dart:io';
// import 'package:excel/excel.dart' as excel;
// import 'package:file_picker/file_picker.dart';
// import 'package:flutter/material.dart';
//
//
// ///الفحص
// class ExcelPickerScreen extends StatefulWidget {
//   const ExcelPickerScreen({super.key});
//
//   @override
//   _ExcelPickerScreenState createState() => _ExcelPickerScreenState();
// }
//
// class _ExcelPickerScreenState extends State<ExcelPickerScreen> {
//   String? _pickedFilePath;
//   List<List<excel.Data?>>? _excelData;
//
//   void _pickFile() async {
//     String? path = await FilePicker.platform.pickFiles(
//       type: FileType.custom,
//       allowedExtensions: ['xls', 'xlsx'],
//     ).then((result) => result?.files.single.path);
//
//     if (path != null) {
//       setState(() {
//         _pickedFilePath = path;
//         _loadExcelData(path);
//       });
//     }
//   }
//
//   void _loadExcelData(String path) {
//     var file = File(path);
//     var bytes = file.readAsBytesSync();
//     var excelFile = excel.Excel.decodeBytes(bytes);
//
//     _excelData = [];
//     for (var table in excelFile.tables.keys) {
//       for (var row in excelFile.tables[table]!.rows) {
//         _excelData!.add(row);
//       }
//     }
//   }
//
//   void _showInputDialog() {
//     final TextEditingController controller = TextEditingController();
//
//     showDialog(
//       context: context,
//       builder: (context) {
//         return AlertDialog(
//           title: Text('أدخل الرقم'),
//           content: TextField(
//             controller: controller,
//             keyboardType: TextInputType.number,
//             decoration: InputDecoration(hintText: "الرقم"),
//           ),
//           actions: [
//             TextButton(
//               onPressed: () {
//                 Navigator.of(context).pop();
//                 _searchNumber(controller.text);
//               },
//               child: Text('بحث'),
//             ),
//             TextButton(
//               onPressed: () => Navigator.of(context).pop(),
//               child: Text('إلغاء'),
//             ),
//           ],
//         );
//       },
//     );
//   }
//
//   void _searchNumber(String number) {
//     if (_excelData == null) return;
//
//     for (var row in _excelData!) {
//       if (row.isNotEmpty && row[0]?.value.toString() == number) {
//         _showResultDialog(row);
//         return;
//       }
//     }
//
//     _showResultDialog([]);
//   }
//
//   void _showResultDialog(List<excel.Data?> row) {
//     String result = row.isEmpty
//         ? "لم يتم العثور على الرقم."
//         : "البيانات: ${row.map((data) => data?.value.toString()).join(', ')}";
//
//     showDialog(
//       context: context,
//       builder: (context) {
//         return AlertDialog(
//           title: Text('نتيجة البحث'),
//           content: Text(result),
//           actions: [
//             TextButton(
//               onPressed: () => Navigator.of(context).pop(),
//               child: Text('موافق'),
//             ),
//           ],
//         );
//       },
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//           title:Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               IconButton(onPressed: (){
//                 Navigator.pushReplacementNamed(context, '/test_screen');
//               }, icon: Icon(Icons.arrow_back_ios_new)),
//               Text('رفع ملف Excel'),
//               Text(''),
//             ],
//           )
//       ),
//       body: Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             ElevatedButton(
//               onPressed: _pickFile,
//               child: Text('رفع ملف Excel',style: TextStyle(
//                   color: Colors.green
//               ),),
//             ),
//             SizedBox(height: 20),
//             if (_pickedFilePath != null)
//               ElevatedButton(
//                 onPressed: _showInputDialog,
//                 child: Text('بحث عن رقم',style: TextStyle(
//                     color: Colors.green
//                 ),),
//               ),
//           ],
//         ),
//       ),
//     );
//   }
// }
import 'dart:io';
import 'package:excel/excel.dart' as excel;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

class ExcelPickerScreen extends StatefulWidget {
  const ExcelPickerScreen({super.key});

  @override
  _ExcelPickerScreenState createState() => _ExcelPickerScreenState();
}

class _ExcelPickerScreenState extends State<ExcelPickerScreen> {
  String? _pickedFilePath;
  List<List<excel.Data?>>? _excelData;

  void _pickFile() async {
    String? path = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['xls', 'xlsx'],
    ).then((result) => result?.files.single.path);

    if (path != null) {
      setState(() {
        _pickedFilePath = path;
        _loadExcelData(path);
      });
    }
  }

  void _loadExcelData(String path) {
    var file = File(path);
    var bytes = file.readAsBytesSync();
    var excelFile = excel.Excel.decodeBytes(bytes);

    _excelData = [];
    for (var table in excelFile.tables.keys) {
      for (var row in excelFile.tables[table]!.rows) {
        _excelData!.add(row);
      }
    }
  }

  void _showInputDialog() {
    final TextEditingController controller = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('أدخل الرقم'),
          content: TextField(
            controller: controller,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(hintText: "الرقم"),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _searchNumber(controller.text);
              },
              child: Text('بحث'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('إلغاء'),
            ),
          ],
        );
      },
    );
  }

  void _searchNumber(String number) {
    if (_excelData == null) return;

    for (var row in _excelData!) {
      if (row.length > 2 && row[2]?.value.toString() == number) {
        _showResultDialog(row);
        return;
      }
    }

    _showResultDialog([]);
  }

  void _showResultDialog(List<excel.Data?> row) {
    String result = row.isEmpty
        ? "لم يتم العثور على الرقم."
        : "البيانات: ${row.map((data) => data?.value.toString()).join(', ')}";

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('نتيجة البحث'),
          content: Text(result),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('موافق'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(onPressed: (){
                Navigator.pushReplacementNamed(context, '/test_screen');
              }, icon: Icon(Icons.arrow_back_ios_new)),
              Text('رفع ملف Excel'),
              Text(''),
            ],
          )
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: _pickFile,
              child: Text('رفع ملف Excel', style: TextStyle(
                  color: Colors.green
              ),),
            ),
            SizedBox(height: 20),
            if (_pickedFilePath != null)
              ElevatedButton(
                onPressed: _showInputDialog,
                child: Text('بحث عن رقم', style: TextStyle(
                    color: Colors.green
                ),),
              ),
          ],
        ),
      ),
    );
  }
}