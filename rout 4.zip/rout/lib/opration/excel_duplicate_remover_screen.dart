import 'dart:io';

import 'package:excel/excel.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:excel/excel.dart' as excel;

/// الحذف بنفس الملف

class ExxcelDuplicateRemoverScreen extends StatefulWidget {
  const ExxcelDuplicateRemoverScreen({super.key});

  @override
  _ExxcelDuplicateRemoverScreenState createState() =>
      _ExxcelDuplicateRemoverScreenState();
}

class _ExxcelDuplicateRemoverScreenState
    extends State<ExxcelDuplicateRemoverScreen> {
  String? _pickedFilePath;
  List<List<excel.Data?>>? _excelData;
  List<List<excel.Data?>>? _filteredData;

  void _pickFile() async {
    String? path = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['xls', 'xlsx'],
    ).then((result) => result?.files.single.path);

    if (path != null) {
      setState(() {
        _pickedFilePath = path;
        _loadExcelData(path);
      });
    }
  }

  void _loadExcelData(String path) {
    var file = File(path);
    var bytes = file.readAsBytesSync();
    var excel = Excel.decodeBytes(bytes);

    _excelData = [];
    for (var table in excel.tables.keys) {
      for (var row in excel.tables[table]!.rows) {
        _excelData!.add(row);
      }
    }

    _removeDuplicates();
  }

  void _removeDuplicates() {
    if (_excelData == null) return;

    Set<String> seen = {};
    _filteredData = [];

    for (var row in _excelData!) {
      if (row.length >= 2) {
        String key1 = row[0]?.value.toString() ?? "";
        String key2 = row[1]?.value.toString() ?? "";

        if (!seen.contains(key1) && !seen.contains(key2)) {
          seen.add(key1);
          seen.add(key2);
          _filteredData!.add(row);
        }
      }
    }

    _showResultDialog();
  }

  void _showResultDialog() {
    String result = _filteredData != null
        ? "عدد الصفوف بعد الحذف: ${_filteredData!.length}"
        : "لا توجد بيانات.";

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('نتيجة الفحص'),
          content: Text(result),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('موافق'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButton(
              onPressed: () {
                // Navigator.of(context).pop();
              },
              icon: const Text('')),
          const Text('حذف التكرارات من ملف Excel'),
          const Text(''),
        ],
      )),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: _pickFile,
              child: const Text(
                'رفع ملف Excel',
                style: TextStyle(color: Colors.green),
              ),
            ),
            const SizedBox(height: 20),
            if (_pickedFilePath != null)
              Text('تم اختيار الملف: $_pickedFilePath'),
          ],
        ),
      ),
    );
  }
}
