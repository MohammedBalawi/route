// import 'dart:io';
//
// import 'package:excel/excel.dart';
// import 'package:file_picker/file_picker.dart';
// import 'package:flutter/material.dart';
//
// class ExcelProcessor extends StatefulWidget {
//   const ExcelProcessor({super.key});
//
//   @override
//   _ExcelProcessorState createState() => _ExcelProcessorState();
// }
//
// class _ExcelProcessorState extends State<ExcelProcessor> {
//   File? selectedFile;
//   Excel? excelData;
//
//   Future<void> pickFile() async {
//     FilePickerResult? result = await FilePicker.platform.pickFiles(
//       type: FileType.custom,
//       allowedExtensions: ['xlsx'],
//     );
//     if (result != null) {
//       selectedFile = File(result.files.single.path!);
//       var bytes = selectedFile!.readAsBytesSync();
//       excelData = Excel.decodeBytes(bytes);
//       setState(() {});
//     }
//   }
//
//   void highlightDuplicatesInFirstColumn() {
//     if (excelData != null) {
//       for (var sheet in excelData!.sheets.values) {
//         final seen = <dynamic>{};
//         for (var row in sheet.rows) {
//           if (!seen.add(row[0]?.value)) {
//             row[0]?.cellStyle = CellStyle(backgroundColorHex: "#FF0000");
//             row[1]?.cellStyle = CellStyle(backgroundColorHex: "#FF0000");
//           }
//         }
//       }
//       setState(() {});
//     }
//   }
//
//   Future<void> saveFile() async {
//     if (selectedFile != null && excelData != null) {
//       var fileBytes = excelData!.encode();
//       if (fileBytes != null) {
//         await File(selectedFile!.path).writeAsBytes(fileBytes, flush: true);
//         ScaffoldMessenger.of(context).showSnackBar(
//           const SnackBar(content: Text('File saved successfully.')),
//         );
//       }
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//           title: Row(
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//         children: [
//           IconButton(
//               onPressed: () {
//                 Navigator.pushReplacementNamed(context, '/test_screen');
//               },
//               icon: const Icon(Icons.arrow_back_ios_new)),
//           const Text('Excel Processor'),
//           const Text(''),
//         ],
//       )),
//       body: Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             ElevatedButton(
//               onPressed: pickFile,
//               child: const Text(
//                 'Select Excel File',
//                 style: TextStyle(color: Colors.green),
//               ),
//             ),
//             if (selectedFile != null) ...[
//               const SizedBox(height: 25),
//               ElevatedButton(
//                 onPressed: highlightDuplicatesInFirstColumn,
//                 child: const Text(
//                   'Color Duplicates',
//                   style: TextStyle(color: Colors.green),
//                 ),
//               ),
//               const SizedBox(height: 10),
//               ElevatedButton(
//                 onPressed: saveFile,
//                 child: const Text(
//                   'Save File',
//                   style: TextStyle(color: Colors.green),
//                 ),
//               ),
//             ],
//           ],
//         ),
//       ),
//     );
//   }
// }
import 'dart:io';

import 'package:excel/excel.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

class ExcelProcessor extends StatefulWidget {
  const ExcelProcessor({super.key});

  @override
  _ExcelProcessorState createState() => _ExcelProcessorState();
}

class _ExcelProcessorState extends State<ExcelProcessor> {
  File? selectedFile;
  Excel? excelData;

  Future<void> pickFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['xlsx'],
    );
    if (result != null) {
      selectedFile = File(result.files.single.path!);
      var bytes = selectedFile!.readAsBytesSync();
      excelData = Excel.decodeBytes(bytes);
      setState(() {});
    }
  }

  void highlightDuplicatesInFirstColumn() {
    if (excelData != null) {
      for (var sheet in excelData!.sheets.values) {
        final seenFirstColumn = <dynamic>{};
        final seenSecondColumn = <dynamic>{};
        for (var row in sheet.rows) {
          // Check first column
          if (!seenFirstColumn.add(row[0]?.value)) {
            row[0]?.cellStyle = CellStyle(backgroundColorHex: "#FF0000");
          }
          // Check second column
          if (!seenSecondColumn.add(row[1]?.value)) {
            row[1]?.cellStyle = CellStyle(backgroundColorHex: "#FF0000");
          }
        }
      }
      setState(() {});
    }
  }

  Future<void> saveFile() async {
    if (selectedFile != null && excelData != null) {
      var fileBytes = excelData!.encode();
      if (fileBytes != null) {
        await File(selectedFile!.path).writeAsBytes(fileBytes, flush: true);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('File saved successfully.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                  onPressed: () {
                    Navigator.pushReplacementNamed(context, '/test_screen');
                  },
                  icon: const Icon(Icons.arrow_back_ios_new)),
              const Text('Excel Processor'),
              const Text(''),
            ],
          )),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: pickFile,
              child: const Text(
                'Select Excel File',
                style: TextStyle(color: Colors.green),
              ),
            ),
            if (selectedFile != null) ...[
              const SizedBox(height: 25),
              ElevatedButton(
                onPressed: highlightDuplicatesInFirstColumn,
                child: const Text(
                  'Color Duplicates',
                  style: TextStyle(color: Colors.green),
                ),
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: saveFile,
                child: const Text(
                  'Save File',
                  style: TextStyle(color: Colors.green),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}