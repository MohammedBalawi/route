// import 'dart:io';
// import 'package:excel/excel.dart';
// import 'package:file_picker/file_picker.dart';
// import 'package:flutter/material.dart';
// import 'package:path_provider/path_provider.dart';
//
// class ExcelComparisonScreen extends StatefulWidget {
//   const ExcelComparisonScreen({super.key});
//
//   @override
//   _ExcelComparisonScreenState createState() => _ExcelComparisonScreenState();
// }
//
// class _ExcelComparisonScreenState extends State<ExcelComparisonScreen> {
//   String? duplicatesFilePath;
//   List<List<Data?>> duplicates = [];
//
//   Future<void> pickAndCompareFiles() async {
//     try {
//       // Pick two files
//       FilePickerResult? result = await FilePicker.platform.pickFiles(
//         allowMultiple: true,
//         type: FileType.custom,
//         allowedExtensions: ['xlsx'],
//       );
//
//       if (result == null || result.files.length != 2) {
//         return;
//       }
//
//       var file1 = result.files[0];
//       var file2 = result.files[1];
//
//       // Read Excel files
//       var bytes1 = File(file1.path!).readAsBytesSync();
//       var bytes2 = File(file2.path!).readAsBytesSync();
//
//       var excel1 = Excel.decodeBytes(bytes1);
//       var excel2 = Excel.decodeBytes(bytes2);
//
//       // Get data from both files
//       var sheet1 = excel1.tables[excel1.tables.keys.first]!;
//       var sheet2 = excel2.tables[excel2.tables.keys.first]!;
//
//       // Find duplicates based on the first two columns
//       Set<String> file1Keys = {};
//       duplicates.clear();
//
//       for (var row in sheet1.rows) {
//         if (row.length >= 2) {
//           String key = '${row[0]?.value}-${row[1]?.value}';
//           file1Keys.add(key);
//         }
//       }
//
//       for (var row in sheet2.rows) {
//         if (row.length >= 2) {
//           String key = '${row[0]?.value}-${row[1]?.value}';
//           if (file1Keys.contains(key)) {
//             duplicates.add(row);
//           }
//         }
//       }
//
//       if (duplicates.isNotEmpty) {
//         _showOptionsDialog();
//       } else {
//         _showResultDialog("لا توجد بيانات مكررة بين الملفين.");
//       }
//     } catch (e) {
//       print("Error: $e");
//     }
//   }
//
//   Future<void> _saveDuplicatesToFile() async {
//     var newExcel = Excel.createExcel();
//     Sheet newSheet = newExcel['Duplicates'];
//
//     for (var row in duplicates) {
//       List<Object?> newRow = [];
//       for (var cell in row) {
//         if (cell?.value != null) {
//           newRow.add(cell!.value.toString());
//         }
//       }
//       newSheet.appendRow(newRow);
//     }
//
//     final directory = await getApplicationDocumentsDirectory();
//     String newPath = '${directory.path}/duplicates.xlsx';
//     File(newPath)
//       ..createSync(recursive: true)
//       ..writeAsBytesSync(newExcel.encode()!);
//
//     setState(() {
//       duplicatesFilePath = newPath;
//     });
//
//     _showResultDialog("تم حفظ البيانات المكررة في: $newPath");
//   }
//
//   void _showOptionsDialog() {
//     showDialog(
//       context: context,
//       builder: (context) {
//         return AlertDialog(
//           title: const Text('البيانات المكررة'),
//           content: const Text('اختر ما تريد فعله بالبيانات المكررة:'),
//           actions: [
//             TextButton(
//               onPressed: () {
//                 Navigator.of(context).pop();
//                 _showDuplicatesInUI();
//               },
//               child: const Text('عرض في الواجهة'),
//             ),
//             TextButton(
//               onPressed: () {
//                 Navigator.of(context).pop();
//                 _saveDuplicatesToFile();
//               },
//               child: const Text('حفظ في ملف'),
//             ),
//           ],
//         );
//       },
//     );
//   }
//
//   void _showDuplicatesInUI() {
//     showDialog(
//       context: context,
//       builder: (context) {
//         return AlertDialog(
//           title: const Text('البيانات المكررة'),
//           content: SingleChildScrollView(
//             child: Column(
//               children: duplicates.map((row) {
//                 String rowText = row.map((cell) => cell?.value?.toString() ?? '').join(', ');
//                 return Column(
//                   children: [
//                     Text(rowText),
//                     const Divider(), // Line between data
//                   ],
//                 );
//               }).toList(),
//             ),
//           ),
//           actions: [
//             TextButton(
//               onPressed: () => Navigator.of(context).pop(),
//               child: const Text('موافق'),
//             ),
//           ],
//         );
//       },
//     );
//   }
//
//   void _showResultDialog(String message) {
//     showDialog(
//       context: context,
//       builder: (context) {
//         return AlertDialog(
//           title: const Text('نتيجة المقارنة'),
//           content: Text(message),
//           actions: [
//             TextButton(
//               onPressed: () => Navigator.of(context).pop(),
//               child: const Text('موافق'),
//             ),
//           ],
//         );
//       },
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Row(
//           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//           children: [
//             IconButton(
//               onPressed: () {
//                 Navigator.pushReplacementNamed(context, '/test_screen');
//               },
//               icon: const Icon(Icons.arrow_back_ios_new),
//             ),
//             const Text('مقارنة ملفات Excel'),
//             const Text(''),
//           ],
//         ),
//       ),
//       body: Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             ElevatedButton(
//               onPressed: pickAndCompareFiles,
//               child: const Text(
//                 'اختر ملفين للمقارنة',
//                 style: TextStyle(
//                   color: Colors.green,
//                 ),
//               ),
//             ),
//             SizedBox(height: 20),
//             if (duplicatesFilePath != null)
//               Text(
//                 'تم حفظ البيانات المكررة في: $duplicatesFilePath',
//                 textAlign: TextAlign.center,
//               ),
//           ],
//         ),
//       ),
//     );
//   }
// }


// import 'dart:io';
// import 'package:excel/excel.dart';
// import 'package:file_picker/file_picker.dart';
// import 'package:flutter/material.dart';
// import 'package:path_provider/path_provider.dart';
//
// class ExcelComparisonScreen extends StatefulWidget {
//   const ExcelComparisonScreen({super.key});
//
//   @override
//   _ExcelComparisonScreenState createState() => _ExcelComparisonScreenState();
// }
//
// class _ExcelComparisonScreenState extends State<ExcelComparisonScreen> {
//   String? filePath1;
//   String? filePath2;
//   List<List<Data?>> duplicates = [];
//   List<List<Data?>> nonDuplicates = [];
//
//   Future<void> pickFile(int fileNumber) async {
//     try {
//       FilePickerResult? result = await FilePicker.platform.pickFiles(
//         type: FileType.custom,
//         allowedExtensions: ['xlsx'],
//       );
//
//       if (result != null && result.files.isNotEmpty) {
//         setState(() {
//           if (fileNumber == 1) {
//             filePath1 = result.files.single.path;
//           } else {
//             filePath2 = result.files.single.path;
//           }
//         });
//       }
//     } catch (e) {
//       print("Error: $e");
//     }
//   }
//
//   Future<void> compareFiles() async {
//     if (filePath1 == null || filePath2 == null) {
//       _showResultDialog("يرجى اختيار كلا الملفين.");
//       return;
//     }
//
//     try {
//       var bytes1 = File(filePath1!).readAsBytesSync();
//       var bytes2 = File(filePath2!).readAsBytesSync();
//
//       var excel1 = Excel.decodeBytes(bytes1);
//       var excel2 = Excel.decodeBytes(bytes2);
//
//       var sheet1 = excel1.tables[excel1.tables.keys.first]!;
//       var sheet2 = excel2.tables[excel2.tables.keys.first]!;
//
//       Set<String> file1Keys = {};
//       duplicates.clear();
//       nonDuplicates.clear();
//
//       for (var row in sheet1.rows) {
//         if (row.length >= 2) {
//           String key = '${row[0]?.value}-${row[1]?.value}';
//           file1Keys.add(key);
//         }
//       }
//
//       for (var row in sheet2.rows) {
//         if (row.length >= 2) {
//           String key = '${row[0]?.value}-${row[1]?.value}';
//           if (file1Keys.contains(key)) {
//             duplicates.add(row);
//           } else {
//             nonDuplicates.add(row);
//           }
//         }
//       }
//
//       _showOptionsDialog();
//     } catch (e) {
//       print("Error: $e");
//     }
//   }
//
//   Future<void> _saveToFile(List<List<Data?>> rows, String fileName) async {
//     var newExcel = Excel.createExcel();
//     Sheet newSheet = newExcel['Sheet1'];
//
//     for (var row in rows) {
//       List<Object?> newRow = [];
//       for (var cell in row) {
//         if (cell?.value != null) {
//           newRow.add(cell!.value.toString());
//         }
//       }
//       newSheet.appendRow(newRow);
//     }
//
//     final directory = await getApplicationDocumentsDirectory();
//     String newPath = '${directory.path}/$fileName';
//     File(newPath)
//       ..createSync(recursive: true)
//       ..writeAsBytesSync(newExcel.encode()!);
//
//     _showResultDialog("تم حفظ البيانات في: $newPath");
//   }
//
//   void _showOptionsDialog() {
//     showDialog(
//       context: context,
//       builder: (context) {
//         return AlertDialog(
//           title: const Text('البيانات المكررة'),
//           content: const Text('اختر ما تريد فعله:'),
//           actions: [
//             TextButton(
//               onPressed: () {
//                 Navigator.of(context).pop();
//                 _showDuplicatesInUI();
//               },
//               child: const Text('عرض المكررات في الواجهة'),
//             ),
//             TextButton(
//               onPressed: () {
//                 Navigator.of(context).pop();
//                 _saveToFile(duplicates, 'duplicates.xlsx');
//               },
//               child: const Text('حفظ المكررات في ملف'),
//             ),
//             TextButton(
//               onPressed: () {
//                 Navigator.of(context).pop();
//                 _saveToFile(nonDuplicates, 'non_duplicates.xlsx');
//               },
//               child: const Text('حفظ الغير مكررات في ملف'),
//             ),
//           ],
//         );
//       },
//     );
//   }
//
//   void _showDuplicatesInUI() {
//     showDialog(
//       context: context,
//       builder: (context) {
//         return AlertDialog(
//           title: const Text('البيانات المكررة'),
//           content: SingleChildScrollView(
//             child: Column(
//               children: duplicates.map((row) {
//                 String rowText = row.map((cell) => cell?.value?.toString() ?? '').join(', ');
//                 return Column(
//                   children: [
//                     Text(rowText),
//                     const Divider(),
//                   ],
//                 );
//               }).toList(),
//             ),
//           ),
//           actions: [
//             TextButton(
//               onPressed: () => Navigator.of(context).pop(),
//               child: const Text('موافق'),
//             ),
//           ],
//         );
//       },
//     );
//   }
//
//   void _showResultDialog(String message) {
//     showDialog(
//       context: context,
//       builder: (context) {
//         return AlertDialog(
//           title: const Text('نتيجة المقارنة'),
//           content: Text(message),
//           actions: [
//             TextButton(
//               onPressed: () => Navigator.of(context).pop(),
//               child: const Text('موافق'),
//             ),
//           ],
//         );
//       },
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Row(
//           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//           children: [
//             IconButton(
//               onPressed: () {
//                 Navigator.pushReplacementNamed(context, '/test_screen');
//               },
//               icon: const Icon(Icons.arrow_back_ios_new),
//             ),
//             const Text('مقارنة ملفات Excel'),
//             const Text(''),
//           ],
//         ),
//       ),
//       body: Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             ElevatedButton(
//               onPressed: () => pickFile(1),
//               child: const Text(
//                 'اختر الملف الأول',
//                 style: TextStyle(
//                   color: Colors.green,
//                 ),
//               ),
//             ),
//             if (filePath1 != null) Text('المسارالاول: $filePath1', textAlign: TextAlign.center),
//             const SizedBox(height: 20),
//             ElevatedButton(
//               onPressed: () => pickFile(2),
//               child: const Text(
//                 'اختر الملف الثاني',
//                 style: TextStyle(
//                   color: Colors.green,
//                 ),
//               ),
//             ),
//             if (filePath2 != null) Text('المسارالتاني: $filePath2', textAlign: TextAlign.center),
//             const SizedBox(height: 20),
//             ElevatedButton(
//               onPressed: compareFiles,
//               child: const Text(
//                 'قارن الملفات',
//                 style: TextStyle(
//                   color: Colors.green,
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }


import 'dart:io';
import 'package:excel/excel.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';

class ExcelComparisonScreen extends StatefulWidget {
  const ExcelComparisonScreen({super.key});

  @override
  _ExcelComparisonScreenState createState() => _ExcelComparisonScreenState();
}

class _ExcelComparisonScreenState extends State<ExcelComparisonScreen> {
  String? filePath1;
  String? filePath2;
  List<List<Data?>> duplicates = [];
  List<List<Data?>> nonDuplicates = [];

  Future<void> pickFile(int fileNumber) async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['xlsx'],
      );

      if (result != null && result.files.isNotEmpty) {
        setState(() {
          if (fileNumber == 1) {
            filePath1 = result.files.single.path;
          } else {
            filePath2 = result.files.single.path;
          }
        });
      }
    } catch (e) {
      print("Error: $e");
    }
  }

  Future<void> compareFiles() async {
    if (filePath1 == null || filePath2 == null) {
      _showResultDialog("يرجى اختيار كلا الملفين.");
      return;
    }

    try {
      var bytes1 = File(filePath1!).readAsBytesSync();
      var bytes2 = File(filePath2!).readAsBytesSync();

      var excel1 = Excel.decodeBytes(bytes1);
      var excel2 = Excel.decodeBytes(bytes2);

      var sheet1 = excel1.tables[excel1.tables.keys.first]!;
      var sheet2 = excel2.tables[excel2.tables.keys.first]!;

      Set<String> file1Keys = {};
      duplicates.clear();
      nonDuplicates.clear();

      for (var row in sheet1.rows) {
        if (row.length >= 2) {
          String key = '${row[0]?.value}-${row[1]?.value}';
          file1Keys.add(key);
        }
      }

      for (var row in sheet2.rows) {
        if (row.length >= 2) {
          String key = '${row[0]?.value}-${row[1]?.value}';
          if (file1Keys.contains(key)) {
            duplicates.add(row);
          } else {
            nonDuplicates.add(row);
          }
        }
      }

      _showOptionsDialog();
    } catch (e) {
      print("Error: $e");
    }
  }

  void _showOptionsDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('الخيارات'),
          content: const Text('اختر ما تريد فعله:'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _showDuplicatesInUI();
              },
              child: const Text('عرض المكررات في الواجهة'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _showNonDuplicatesInUI();
              },
              child: const Text('عرض الغير مكررات في الواجهة'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _saveToFile(duplicates, 'duplicates.xlsx');
              },
              child: const Text('حفظ المكررات في ملف'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _saveToFile(nonDuplicates, 'non_duplicates.xlsx');
              },
              child: const Text('حفظ الغير مكررات في ملف'),
            ),
          ],
        );
      },
    );
  }

  void _showDuplicatesInUI() {
    _showDataInUI(duplicates, 'البيانات المكررة');
  }

  void _showNonDuplicatesInUI() {
    _showDataInUI(nonDuplicates, 'البيانات الغير مكررة');
  }

  void _showDataInUI(List<List<Data?>> data, String title) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(title),
          content: SingleChildScrollView(
            child: Column(
              children: data.map((row) {
                String rowText = row.map((cell) => cell?.value?.toString() ?? '').join(', ');
                return Column(
                  children: [
                    Text(rowText),
                    const Divider(),
                  ],
                );
              }).toList(),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('موافق'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _saveToFile(List<List<Data?>> rows, String fileName) async {
    var newExcel = Excel.createExcel();
    Sheet newSheet = newExcel['Sheet1'];

    for (var row in rows) {
      List<Object?> newRow = [];
      for (var cell in row) {
        if (cell?.value != null) {
          newRow.add(cell!.value.toString());
        }
      }
      newSheet.appendRow(newRow);
    }

    final directory = await getApplicationDocumentsDirectory();
    String newPath = '${directory.path}/$fileName';
    File(newPath)
      ..createSync(recursive: true)
      ..writeAsBytesSync(newExcel.encode()!);

    _showResultDialog("تم حفظ البيانات في: $newPath");
  }

  void _showResultDialog(String message) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('نتيجة المقارنة'),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('موافق'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            IconButton(
              onPressed: () {
                Navigator.pushReplacementNamed(context, '/test_screen');
              },
              icon: const Icon(Icons.arrow_back_ios_new),
            ),
            const Text('مقارنة ملفات Excel'),
            const Text(''),
          ],
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () => pickFile(1),
              child: const Text(
                'اختر الملف الأول',
                style: TextStyle(
                  color: Colors.green,
                ),
              ),
            ),
            if (filePath1 != null) Text('المسار الاول: $filePath1', textAlign: TextAlign.center),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => pickFile(2),
              child: const Text(
                'اختر الملف الثاني',
                style: TextStyle(
                  color: Colors.green,
                ),
              ),
            ),
            if (filePath2 != null) Text('المسار التاني: $filePath2', textAlign: TextAlign.center),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: compareFiles,
              child: const Text(
                'قارن الملفات',
                style: TextStyle(
                  color: Colors.green,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}