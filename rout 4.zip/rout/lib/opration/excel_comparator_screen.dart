import 'dart:io';

import 'package:excel/excel.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

/// // المقارنة


class ExcellComparator extends StatefulWidget {
  const ExcellComparator({super.key});

  @override
  _ExcellComparatorState createState() => _ExcellComparatorState();
}

class _ExcellComparatorState extends State<ExcellComparator> {
  List<List<String>> duplicates = [];

  Future<void> pickAndCompareFiles() async {
    try {
      // Pick two files
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        allowMultiple: true,
        type: FileType.custom,
        allowedExtensions: ['xlsx'],
      );

      if (result == null || result.files.length != 2) {
        return;
      }

      var file1 = result.files[0];
      var file2 = result.files[1];

      // Read Excel files
      var bytes1 = File(file1.path!).readAsBytesSync();
      var bytes2 = File(file2.path!).readAsBytesSync();

      var excel1 = Excel.decodeBytes(bytes1);
      var excel2 = Excel.decodeBytes(bytes2);

      // Assuming data is in the first sheet
      var sheet1 = excel1.tables[excel1.tables.keys.first]!;
      var sheet2 = excel2.tables[excel2.tables.keys.first]!;

      var set1 = <String>{};
      var set2 = <String>{};

      // Read data from first file
      for (var row in sheet1.rows) {
        var key = "${row[0]?.value}-${row[1]?.value}";
        set1.add(key);
      }

      // Read data from second file
      for (var row in sheet2.rows) {
        var key = "${row[0]?.value}-${row[1]?.value}";
        set2.add(key);
      }

      // Find duplicates
      duplicates = set1.intersection(set2).map((e) => e.split('-')).toList();

      if (duplicates.isNotEmpty) {
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text("تكرار موجود"),
              content: const Text("يوجد تكرار بين الملفين."),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: const Text("إلغاء"),
                ),
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    _showDuplicates();
                  },
                  child: const Text("عرض التكرار"),
                ),
              ],
            );
          },
        );
      }
    } catch (e) {
      print("Error: $e");
    }
  }

  void _showDuplicates() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("التكرارات"),
          content: Container(
            width: double.maxFinite,
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: duplicates.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text("الصف ${duplicates[index][0]} - ${duplicates[index][1]}"),
                );
              },
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text("إغلاق"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(onPressed: (){
                Navigator.pushReplacementNamed(context, '/test_screen');
              }, icon: const Icon(Icons.arrow_back_ios_new)),
              const Text('مقارنة ملفات Excel'),
              const Text(''),
            ],
          )

      ),
      body: Center(
        child: ElevatedButton(
          onPressed: pickAndCompareFiles,
          child: const Text('اختر ملفين للمقارنة', style: TextStyle(
            color: Colors.green,
          ),),
        ),
      ),
    );
  }
}

