import 'package:Excel_Rout/screen/login_screen.dart';
import 'package:Excel_Rout/shared_pref/shared.dart';
import 'package:flutter/material.dart';
import 'cv/my_cv_screen.dart';
import 'opration/excel_comparator_screen.dart';
import 'opration/excel_delete_screen.dart';
import 'opration/excel_duplicate_remover_screen.dart';
import 'home/excel_howe.dart';
import 'opration/excel_merge_screen.dart';
import 'opration/excel_comparison_screen.dart';
import 'opration/excel_picker_screen.dart';
import 'opration/excel_processor_screen.dart';
import 'opration/excel_remover_screen.dart';
import 'opration/tt.dart';
import 'screen/launch_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SharedPrefController().initPreferences();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return  MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute:'/launch_screen',
      routes: {
        '/launch_screen': (context)=>  const LaunchScreen(),
        '/excel_processor': (context)=>  const ExcelProcessor(),
        '/test_screen': (context)=>  const test(),
        '/excel_picker_screen': (context)=>  const ExcelPickerScreen(),
        '/excel_remover_screen': (context)=>  const ExxcelDuplicateRemoverScreen(),
        '/excel_duplicate_screen': (context)=>  const ExcelDuplicateRemoverScreen(),
        '/excel_merger_screen': (context)=>  const ExcelMergerScreen(),
        '/excel_comparator': (context)=>  const ExcellComparator(),
        '/excel_delete_screen': (context)=>  const ExcelDeleteScreen(),
        '/excel_comparison_screen': (context)=>  const ExcelComparisonScreen(),
        '/notes_screen': (context)=>   const NotesScreen(),
        '/login_screen': (context)=>   const LoginScreen(),
        '/my_cv_screen': (context)=>   const MyCVScreen(),
      },
    );
  }
}

